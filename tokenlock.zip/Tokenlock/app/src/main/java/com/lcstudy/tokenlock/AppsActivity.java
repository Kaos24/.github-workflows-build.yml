package com.lcstudy.tokenlock;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;

/** Lets you choose how many tokens each app costs, including free. */
public class AppsActivity extends Activity {

    private static final class App {
        String pkg;
        String label;
    }

    private final ArrayList<App> all = new ArrayList<>();
    private final ArrayList<App> shown = new ArrayList<>();
    private final HashMap<String, Drawable> icons = new HashMap<>();
    private Adapter adapter;
    private TextView loading;
    private String filter = "";

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Ui.BG);
        int pad = Ui.dp(this, 20);
        root.setPadding(pad, Ui.dp(this, 32), pad, 0);

        root.addView(Ui.text(this, "App costs", 26, Ui.TEXT, true));
        TextView sub = Ui.text(this, "Tap an app to choose how many tokens it costs to open.", 14, Ui.MUTED, false);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.topMargin = Ui.dp(this, 4);
        root.addView(sub, lp);

        EditText search = new EditText(this);
        search.setHint("Search apps");
        search.setHintTextColor(Ui.MUTED);
        search.setTextColor(Ui.TEXT);
        search.setSingleLine(true);
        search.setInputType(InputType.TYPE_CLASS_TEXT);
        search.setBackground(Ui.round(this, Ui.CARD, 14));
        int ip = Ui.dp(this, 12);
        search.setPadding(ip, ip, ip, ip);
        search.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int c, int d) {}
            @Override public void onTextChanged(CharSequence s, int a, int c, int d) {}
            @Override public void afterTextChanged(Editable s) {
                filter = s.toString().trim().toLowerCase(Locale.ROOT);
                applyFilter();
            }
        });
        lp = new LinearLayout.LayoutParams(-1, -2);
        lp.topMargin = Ui.dp(this, 14);
        root.addView(search, lp);

        loading = Ui.text(this, "Loading your apps…", 14, Ui.MUTED, false);
        lp = new LinearLayout.LayoutParams(-1, -2);
        lp.topMargin = Ui.dp(this, 16);
        root.addView(loading, lp);

        ListView list = new ListView(this);
        list.setDivider(null);
        list.setSelector(android.R.color.transparent);
        adapter = new Adapter();
        list.setAdapter(adapter);
        list.setOnItemClickListener((parent, view, position, id) -> choose(shown.get(position)));
        lp = new LinearLayout.LayoutParams(-1, 0, 1f);
        lp.topMargin = Ui.dp(this, 8);
        root.addView(list, lp);

        setContentView(root);

        new Thread(() -> {
            ArrayList<App> apps = loadApps();
            runOnUiThread(() -> {
                all.clear();
                all.addAll(apps);
                loading.setVisibility(View.GONE);
                applyFilter();
            });
        }).start();
    }

    private ArrayList<App> loadApps() {
        PackageManager pm = getPackageManager();
        Intent i = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER);
        List<ResolveInfo> infos = pm.queryIntentActivities(i, 0);
        HashSet<String> seen = new HashSet<>();
        ArrayList<App> out = new ArrayList<>();
        for (ResolveInfo r : infos) {
            String pkg = r.activityInfo.packageName;
            if (pkg.equals(getPackageName()) || !seen.add(pkg)) continue;
            App a = new App();
            a.pkg = pkg;
            try {
                a.label = pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString();
            } catch (Exception e) {
                a.label = r.loadLabel(pm).toString();
            }
            out.add(a);
        }
        Collections.sort(out, (x, y) -> x.label.compareToIgnoreCase(y.label));
        return out;
    }

    private void applyFilter() {
        shown.clear();
        for (App a : all) {
            if (filter.isEmpty() || a.label.toLowerCase(Locale.ROOT).contains(filter)) shown.add(a);
        }
        adapter.notifyDataSetChanged();
    }

    private void choose(App a) {
        if (Config.alwaysFree(this, a.pkg)) {
            new AlertDialog.Builder(this)
                    .setTitle(a.label)
                    .setMessage("This app is always free, so you can never be locked out of calls, alarms or settings.")
                    .setPositiveButton("OK", null)
                    .show();
            return;
        }
        Store st = Store.get(this);
        int def = Config.defaultCost(a.pkg);
        int n = Config.COST_CHOICES.length;
        String[] labels = new String[n + 1];
        for (int k = 0; k < n; k++) labels[k] = Config.label(Config.COST_CHOICES[k]);
        labels[n] = "Reset to default (" + Config.label(def) + ")";
        new AlertDialog.Builder(this)
                .setTitle(a.label)
                .setItems(labels, (d, which) -> {
                    st.setCostOverride(a.pkg, which == n ? -1 : Config.COST_CHOICES[which]);
                    adapter.notifyDataSetChanged();
                })
                .show();
    }

    private final class Adapter extends BaseAdapter {
        @Override public int getCount() { return shown.size(); }
        @Override public Object getItem(int position) { return shown.get(position); }
        @Override public long getItemId(int position) { return position; }

        @Override
        public View getView(int position, View convert, ViewGroup parent) {
            Row row = convert instanceof Row ? (Row) convert : new Row();
            App a = shown.get(position);
            Drawable icon = icons.get(a.pkg);
            if (icon == null) {
                try { icon = getPackageManager().getApplicationIcon(a.pkg); } catch (Exception ignored) {}
                if (icon != null) icons.put(a.pkg, icon);
            }
            row.icon.setImageDrawable(icon);
            row.name.setText(a.label);

            boolean locked = Config.alwaysFree(AppsActivity.this, a.pkg);
            int override = Store.get(AppsActivity.this).costOverride(a.pkg);
            int cost = Config.cost(AppsActivity.this, a.pkg);
            row.note.setText(locked ? "Always free" : override >= 0 ? "Custom" : "Default");
            row.chip.setText(Config.label(cost));
            int col = cost == 0 ? Ui.GOOD : cost >= Config.HIGH_COST ? Ui.BAD : Ui.COIN;
            row.chip.setTextColor(col);
            row.chip.setBackground(Ui.round(AppsActivity.this, (col & 0x00FFFFFF) | 0x26000000, 14));
            row.setAlpha(locked ? 0.55f : 1f);
            return row;
        }
    }

    private final class Row extends LinearLayout {
        final ImageView icon;
        final TextView name, note, chip;

        Row() {
            super(AppsActivity.this);
            setOrientation(HORIZONTAL);
            setGravity(Gravity.CENTER_VERTICAL);
            int v = Ui.dp(getContext(), 10);
            setPadding(0, v, 0, v);

            icon = new ImageView(getContext());
            int s = Ui.dp(getContext(), 40);
            addView(icon, new LayoutParams(s, s));

            LinearLayout texts = new LinearLayout(getContext());
            texts.setOrientation(VERTICAL);
            name = Ui.text(getContext(), "", 16, Ui.TEXT, false);
            name.setSingleLine(true);
            note = Ui.text(getContext(), "", 12, Ui.MUTED, false);
            texts.addView(name);
            texts.addView(note);
            LayoutParams lp = new LayoutParams(0, -2, 1f);
            lp.leftMargin = Ui.dp(getContext(), 14);
            addView(texts, lp);

            chip = Ui.text(getContext(), "", 13, Ui.COIN, true);
            int h = Ui.dp(getContext(), 12), t = Ui.dp(getContext(), 6);
            chip.setPadding(h, t, h, t);
            addView(chip);
        }
    }
}
