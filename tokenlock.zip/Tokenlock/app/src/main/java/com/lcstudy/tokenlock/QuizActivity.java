package com.lcstudy.tokenlock;

import android.animation.ObjectAnimator;
import android.animation.PropertyValuesHolder;
import android.app.Activity;
import android.content.res.ColorStateList;
import android.graphics.drawable.ColorDrawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.InputType;
import android.view.Gravity;
import android.view.HapticFeedbackConstants;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.view.animation.CycleInterpolator;
import android.view.animation.TranslateAnimation;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

/** The answer popup. Opens over the home screen when you tap the widget. */
public class QuizActivity extends Activity {

    private Store st;
    private QuestionBank bank;
    private Question q;
    private int[] order;
    private boolean attempted, revealed, busy;
    private final Handler handler = new Handler(Looper.getMainLooper());

    private TextView subject, dots, coin, streak, question, feedback, answerBox, level, dailyLabel;
    private TextView btnReveal, btnCheck, btnMark;
    private EditText input;
    private ProgressBar daily;
    private LinearLayout rowMain, rowReveal, choices;
    private final TextView[] choiceViews = new TextView[4];

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        st = Store.get(this);
        bank = QuestionBank.get(this);
        setContentView(build());

        Window w = getWindow();
        w.setBackgroundDrawable(new ColorDrawable(0));
        w.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        w.setGravity(Gravity.BOTTOM);

        show();
    }

    private View build() {
        int pad = Ui.dp(this, 20);
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(pad, pad, pad, pad);
        card.setBackground(Ui.round(this, Ui.BG, 28));

        LinearLayout head = new LinearLayout(this);
        head.setGravity(Gravity.CENTER_VERTICAL);
        subject = Ui.text(this, "", 13, Ui.CS, true);
        subject.setPadding(Ui.dp(this, 10), Ui.dp(this, 4), Ui.dp(this, 10), Ui.dp(this, 4));
        head.addView(subject);
        dots = Ui.text(this, "", 11, Ui.MUTED, false);
        dots.setPadding(Ui.dp(this, 8), 0, 0, 0);
        head.addView(dots);
        head.addView(new View(this), new LinearLayout.LayoutParams(0, 1, 1f));
        streak = Ui.text(this, "", 14, Ui.TEXT, false);
        streak.setPadding(0, 0, Ui.dp(this, 10), 0);
        head.addView(streak);
        coin = Ui.text(this, "0", 15, Ui.ON_COIN, true);
        coin.setGravity(Gravity.CENTER);
        coin.setBackground(Ui.coin(this));
        int cs = Ui.dp(this, 38);
        head.addView(coin, new LinearLayout.LayoutParams(cs, cs));
        card.addView(head);

        question = Ui.text(this, "", 19, Ui.TEXT, false);
        question.setLineSpacing(0, 1.2f);
        card.addView(question, top(16));

        input = new EditText(this);
        input.setHint("Type your answer");
        input.setHintTextColor(Ui.MUTED);
        input.setTextColor(Ui.TEXT);
        input.setTextSize(17);
        input.setSingleLine(true);
        input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        input.setImeOptions(EditorInfo.IME_ACTION_DONE);
        input.setBackground(Ui.round(this, Ui.CARD, 14));
        int ip = Ui.dp(this, 14);
        input.setPadding(ip, ip, ip, ip);
        input.setOnEditorActionListener((v, actionId, e) -> {
            if (revealed) next(); else check();
            return true;
        });
        card.addView(input, top(16));

        choices = new LinearLayout(this);
        choices.setOrientation(LinearLayout.VERTICAL);
        for (int i = 0; i < 4; i++) {
            TextView c = Ui.text(this, "", 16, Ui.TEXT, false);
            c.setPadding(ip, Ui.dp(this, 13), ip, Ui.dp(this, 13));
            c.setBackground(Ui.outline(this, Ui.LINE, 14));
            final int idx = i;
            c.setOnClickListener(v -> pick(idx));
            choiceViews[i] = c;
            choices.addView(c, top(i == 0 ? 0 : 8));
        }
        card.addView(choices, top(16));

        feedback = Ui.text(this, "", 15, Ui.MUTED, true);
        feedback.setVisibility(View.GONE);
        feedback.setLineSpacing(0, 1.2f);
        card.addView(feedback, top(10));

        answerBox = Ui.text(this, "", 16, Ui.TEXT, false);
        answerBox.setBackground(Ui.round(this, Ui.CARD, 14));
        answerBox.setPadding(ip, ip, ip, ip);
        answerBox.setLineSpacing(0, 1.2f);
        answerBox.setVisibility(View.GONE);
        card.addView(answerBox, top(10));

        rowMain = new LinearLayout(this);
        rowMain.setGravity(Gravity.CENTER_VERTICAL);
        btnReveal = Ui.text(this, "Show answer", 14, Ui.MUTED, false);
        btnReveal.setPadding(Ui.dp(this, 4), Ui.dp(this, 12), Ui.dp(this, 12), Ui.dp(this, 12));
        btnReveal.setOnClickListener(v -> reveal());
        rowMain.addView(btnReveal);
        TextView skip = Ui.text(this, "Skip", 14, Ui.MUTED, false);
        skip.setPadding(Ui.dp(this, 12), Ui.dp(this, 12), Ui.dp(this, 12), Ui.dp(this, 12));
        skip.setOnClickListener(v -> skip());
        rowMain.addView(skip);
        rowMain.addView(new View(this), new LinearLayout.LayoutParams(0, 1, 1f));
        btnCheck = Ui.button(this, "Check", true);
        btnCheck.setOnClickListener(v -> check());
        rowMain.addView(btnCheck);
        card.addView(rowMain, top(14));

        rowReveal = new LinearLayout(this);
        rowReveal.setGravity(Gravity.CENTER_VERTICAL);
        btnMark = Ui.text(this, "I had it right", 14, Ui.MUTED, false);
        btnMark.setPadding(Ui.dp(this, 4), Ui.dp(this, 12), Ui.dp(this, 12), Ui.dp(this, 12));
        btnMark.setOnClickListener(v -> markRight());
        rowReveal.addView(btnMark);
        rowReveal.addView(new View(this), new LinearLayout.LayoutParams(0, 1, 1f));
        TextView nextBtn = Ui.button(this, "Next question", true);
        nextBtn.setOnClickListener(v -> next());
        rowReveal.addView(nextBtn);
        rowReveal.setVisibility(View.GONE);
        card.addView(rowReveal, top(14));

        LinearLayout foot = new LinearLayout(this);
        foot.setGravity(Gravity.CENTER_VERTICAL);
        dailyLabel = Ui.text(this, "", 12, Ui.MUTED, false);
        foot.addView(dailyLabel);
        daily = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        daily.setMax(Store.DAILY_GOAL);
        daily.setProgressTintList(ColorStateList.valueOf(Ui.COIN));
        daily.setProgressBackgroundTintList(ColorStateList.valueOf(Ui.LINE));
        LinearLayout.LayoutParams plp = new LinearLayout.LayoutParams(0, Ui.dp(this, 6), 1f);
        plp.leftMargin = Ui.dp(this, 10);
        plp.rightMargin = Ui.dp(this, 10);
        foot.addView(daily, plp);
        level = Ui.text(this, "", 12, Ui.MUTED, false);
        foot.addView(level);
        card.addView(foot, top(12));

        LinearLayout outer = new LinearLayout(this);
        int m = Ui.dp(this, 8);
        outer.setPadding(m, m, m, m);
        outer.addView(card, new LinearLayout.LayoutParams(-1, -2));
        return outer;
    }

    private LinearLayout.LayoutParams top(int dp) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.topMargin = Ui.dp(this, dp);
        return lp;
    }

    /** Shows whatever question is current in the store. */
    private void show() {
        q = bank.get(st.currentId(bank));
        attempted = false;
        revealed = false;
        busy = false;

        subject.setText(q.subjectName());
        subject.setTextColor(q.color());
        subject.setBackground(Ui.round(this, (q.color() & 0x00FFFFFF) | 0x26000000, 12));
        dots.setText(q.isChoice() ? q.dots() + "  multiple choice" : q.dots());
        question.setText(q.text);

        feedback.setVisibility(View.GONE);
        answerBox.setVisibility(View.GONE);
        rowMain.setVisibility(View.VISIBLE);
        rowReveal.setVisibility(View.GONE);

        if (q.isChoice()) {
            order = q.order(st.seed());
            input.setVisibility(View.GONE);
            btnCheck.setVisibility(View.GONE);
            btnReveal.setVisibility(View.GONE);
            choices.setVisibility(View.VISIBLE);
            for (int i = 0; i < 4; i++) {
                TextView c = choiceViews[i];
                if (i < order.length) {
                    c.setVisibility(View.VISIBLE);
                    c.setText(q.options[order[i]]);
                    c.setTextColor(Ui.TEXT);
                    c.setBackground(Ui.outline(this, Ui.LINE, 14));
                    c.setEnabled(true);
                } else {
                    c.setVisibility(View.GONE);
                }
            }
            keyboard(false);
        } else {
            order = null;
            choices.setVisibility(View.GONE);
            input.setVisibility(View.VISIBLE);
            btnCheck.setVisibility(View.VISIBLE);
            btnReveal.setVisibility(View.VISIBLE);
            input.setText("");
            input.setEnabled(true);
            input.requestFocus();
            keyboard(true);
        }
        updateHeader();
    }

    private void keyboard(boolean show) {
        Window w = getWindow();
        InputMethodManager imm = getSystemService(InputMethodManager.class);
        if (show) {
            w.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE
                    | WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
            input.post(() -> { if (imm != null) imm.showSoftInput(input, 0); });
        } else {
            w.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
            if (imm != null) imm.hideSoftInputFromWindow(input.getWindowToken(), 0);
        }
    }

    private void updateHeader() {
        coin.setText(String.valueOf(st.tokens()));
        int s = st.streak();
        streak.setText(s > 0 ? "🔥 " + s : "");
        int today = st.todayCorrect();
        daily.setProgress(Math.min(today, Store.DAILY_GOAL));
        dailyLabel.setText(today >= Store.DAILY_GOAL ? "Daily goal done" : today + " of " + Store.DAILY_GOAL + " today");
        int lvl = st.level();
        int into = st.xp() - Store.levelStart(lvl);
        int span = Store.levelStart(lvl + 1) - Store.levelStart(lvl);
        level.setText("Level " + lvl + "   " + into + "/" + span + " XP");
    }

    // ---------- typed ----------
    private void check() {
        if (busy || revealed || q.isChoice()) return;
        String a = input.getText().toString().trim();
        if (a.isEmpty()) {
            shake(input);
            return;
        }
        attempted = true;
        if (Checker.check(a, q.keys)) {
            win(st.correct(q, false));
        } else {
            st.wrongAttempt();
            feedback.setText("Not quite. Try again, or tap Show answer.");
            feedback.setTextColor(Ui.BAD);
            feedback.setVisibility(View.VISIBLE);
            shake(input);
            haptic(false);
        }
    }

    private void reveal() {
        if (busy || revealed) return;
        revealed = true;
        st.missed(bank, q);
        st.advance(bank); // move on now, so closing the popup never brings this one straight back
        TokenWidget.refresh(this);
        answerBox.setText(q.answer);
        answerBox.setVisibility(View.VISIBLE);
        feedback.setText("No token this time. This one will come back in a while so you can learn it.");
        feedback.setTextColor(Ui.MUTED);
        feedback.setVisibility(View.VISIBLE);
        rowMain.setVisibility(View.GONE);
        rowReveal.setVisibility(View.VISIBLE);
        btnMark.setVisibility(!q.isChoice() && attempted && input.getText().toString().trim().length() >= 2
                ? View.VISIBLE : View.GONE);
        updateHeader();
    }

    private void markRight() {
        if (busy) return;
        rowReveal.setVisibility(View.GONE);
        win(st.correct(q, true));
    }

    // ---------- multiple choice ----------
    private void pick(int displayIndex) {
        if (busy || revealed || order == null) return;
        for (TextView c : choiceViews) c.setEnabled(false);
        int chosen = order[displayIndex];
        int correctDisplay = 0;
        for (int i = 0; i < order.length; i++) if (order[i] == 0) correctDisplay = i;
        TextView right = choiceViews[correctDisplay];
        right.setBackground(Ui.round(this, (Ui.GOOD & 0x00FFFFFF) | 0x33000000, 14));
        right.setTextColor(Ui.GOOD);
        if (chosen == 0) {
            win(st.correct(q, false));
        } else {
            TextView wrong = choiceViews[displayIndex];
            wrong.setBackground(Ui.round(this, (Ui.BAD & 0x00FFFFFF) | 0x33000000, 14));
            wrong.setTextColor(Ui.BAD);
            shake(wrong);
            haptic(false);
            revealed = true;
            st.missed(bank, q);
            st.advance(bank);
            TokenWidget.refresh(this);
            feedback.setText("Not this time. It'll come back in a while.");
            feedback.setTextColor(Ui.BAD);
            feedback.setVisibility(View.VISIBLE);
            if (!q.answer.equals(q.options[0])) {
                answerBox.setText(q.answer);
                answerBox.setVisibility(View.VISIBLE);
            }
            rowMain.setVisibility(View.GONE);
            rowReveal.setVisibility(View.VISIBLE);
            btnMark.setVisibility(View.GONE);
            updateHeader();
        }
    }

    // ---------- shared ----------
    private void win(Store.Reward r) {
        busy = true;
        // Advance straight away so the question can't come back if the popup is closed early.
        if (!revealed) st.advance(bank);
        TokenWidget.refresh(this);

        StringBuilder b = new StringBuilder();
        b.append("Correct  +").append(r.tokens).append(r.tokens == 1 ? " token" : " tokens")
                .append("  +").append(r.xp).append(" XP");
        for (String n : r.notes) b.append('\n').append(n);
        feedback.setText(b.toString());
        feedback.setTextColor(Ui.GOOD);
        feedback.setVisibility(View.VISIBLE);
        if (!q.isChoice()) {
            answerBox.setText(q.answer);
            answerBox.setVisibility(View.VISIBLE);
            input.setEnabled(false);
        }
        haptic(true);
        updateHeader();
        bump(coin);
        handler.postDelayed(() -> {
            if (!isFinishing()) show();
        }, 1300 + 500L * r.notes.size());
    }

    private void next() {
        if (busy) return;
        show(); // the store already moved on when this question was answered or revealed
    }

    private void skip() {
        if (busy) return;
        st.skip(bank);
        TokenWidget.refresh(this);
        show();
    }

    private void shake(View v) {
        TranslateAnimation a = new TranslateAnimation(0, Ui.dp(this, 8), 0, 0);
        a.setDuration(400);
        a.setInterpolator(new CycleInterpolator(3));
        v.startAnimation(a);
    }

    private void bump(View v) {
        ObjectAnimator.ofPropertyValuesHolder(v,
                PropertyValuesHolder.ofFloat(View.SCALE_X, 1f, 1.35f, 1f),
                PropertyValuesHolder.ofFloat(View.SCALE_Y, 1f, 1.35f, 1f))
                .setDuration(450)
                .start();
    }

    private void haptic(boolean good) {
        View v = getWindow().getDecorView();
        if (Build.VERSION.SDK_INT >= 30) {
            v.performHapticFeedback(good ? HapticFeedbackConstants.CONFIRM : HapticFeedbackConstants.REJECT);
        } else {
            v.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP);
        }
    }

    @Override
    protected void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        super.onDestroy();
    }
}
