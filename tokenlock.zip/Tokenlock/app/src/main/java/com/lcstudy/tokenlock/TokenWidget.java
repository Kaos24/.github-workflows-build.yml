package com.lcstudy.tokenlock;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.view.View;
import android.widget.RemoteViews;

/**
 * The home-screen widget. Multiple-choice questions can be answered right on the widget.
 * Typed questions open the answer popup.
 */
public class TokenWidget extends AppWidgetProvider {
    static final String ACTION_SKIP = "com.lcstudy.tokenlock.SKIP";
    static final String ACTION_PICK = "com.lcstudy.tokenlock.PICK";
    private static final String EXTRA_Q = "q";
    private static final String EXTRA_I = "i";

    private static final int[] OPT_IDS = {R.id.w_opt0, R.id.w_opt1, R.id.w_opt2, R.id.w_opt3};

    @Override
    public void onUpdate(Context c, AppWidgetManager m, int[] ids) {
        m.updateAppWidget(ids, build(c));
    }

    @Override
    public void onReceive(Context c, Intent intent) {
        super.onReceive(c, intent);
        String action = intent.getAction();
        if (ACTION_SKIP.equals(action)) {
            Store.get(c).skip(QuestionBank.get(c));
            refresh(c);
        } else if (ACTION_PICK.equals(action)) {
            pick(c, intent.getIntExtra(EXTRA_Q, -1), intent.getIntExtra(EXTRA_I, -1));
        }
    }

    private static void pick(Context c, int qid, int displayIndex) {
        Store st = Store.get(c);
        QuestionBank bank = QuestionBank.get(c);
        int cur = st.currentId(bank);
        Question q = bank.get(cur);
        // Ignore taps on a stale widget (the question already changed).
        if (qid != cur || !q.isChoice() || displayIndex < 0) {
            refresh(c);
            return;
        }
        int[] order = q.order(st.seed());
        if (displayIndex >= order.length) {
            refresh(c);
            return;
        }
        String msg;
        boolean good;
        if (order[displayIndex] == 0) {
            Store.Reward r = st.correct(q, false);
            msg = "✓ Correct  +" + r.tokens + (r.tokens == 1 ? " token" : " tokens")
                    + (r.notes.isEmpty() ? "" : "  " + r.notes.get(0));
            good = true;
        } else {
            st.missed(bank, q);
            msg = "✗ It was: " + q.options[0];
            good = false;
        }
        st.advance(bank);
        st.setFlash(msg, good);
        refresh(c);
    }

    static void refresh(Context c) {
        AppWidgetManager m = AppWidgetManager.getInstance(c);
        int[] ids = m.getAppWidgetIds(new ComponentName(c, TokenWidget.class));
        if (ids == null || ids.length == 0) return;
        m.updateAppWidget(ids, build(c));
    }

    private static RemoteViews build(Context c) {
        Store st = Store.get(c);
        QuestionBank bank = QuestionBank.get(c);
        Question q = bank.get(st.currentId(bank));

        RemoteViews v = new RemoteViews(c.getPackageName(), R.layout.widget);
        v.setTextViewText(R.id.w_coin, String.valueOf(st.tokens()));
        v.setTextViewText(R.id.w_streak, "🔥 " + st.streak());
        int today = st.todayCorrect();
        v.setTextViewText(R.id.w_daily, today >= Store.DAILY_GOAL ? "Goal done" : today + "/" + Store.DAILY_GOAL + " today");
        v.setProgressBar(R.id.w_progress, Store.DAILY_GOAL, Math.min(today, Store.DAILY_GOAL), false);
        v.setTextViewText(R.id.w_subject, q.subjectName() + "  " + q.dots());
        v.setTextColor(R.id.w_subject, q.color());
        v.setTextViewText(R.id.w_question, q.text);

        String flash = st.flash();
        if (flash != null) {
            v.setViewVisibility(R.id.w_feedback, View.VISIBLE);
            v.setTextViewText(R.id.w_feedback, flash);
            v.setTextColor(R.id.w_feedback, st.flashGood() ? Ui.GOOD : Ui.BAD);
        } else {
            v.setViewVisibility(R.id.w_feedback, View.GONE);
        }

        Intent quiz = new Intent(c, QuizActivity.class)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        PendingIntent open = PendingIntent.getActivity(c, 1, quiz,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        v.setOnClickPendingIntent(R.id.w_root, open);
        v.setOnClickPendingIntent(R.id.w_question, open);
        v.setOnClickPendingIntent(R.id.w_answer, open);

        if (q.isChoice()) {
            int[] order = q.order(st.seed());
            v.setViewVisibility(R.id.w_opts, View.VISIBLE);
            v.setViewVisibility(R.id.w_answer, View.GONE);
            for (int i = 0; i < OPT_IDS.length; i++) {
                if (i < order.length) {
                    v.setViewVisibility(OPT_IDS[i], View.VISIBLE);
                    v.setTextViewText(OPT_IDS[i], q.options[order[i]]);
                    Intent pick = new Intent(c, TokenWidget.class)
                            .setAction(ACTION_PICK)
                            .putExtra(EXTRA_Q, q.id)
                            .putExtra(EXTRA_I, i);
                    v.setOnClickPendingIntent(OPT_IDS[i], PendingIntent.getBroadcast(c, 100 + i, pick,
                            PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT));
                } else {
                    v.setViewVisibility(OPT_IDS[i], View.GONE);
                }
            }
        } else {
            v.setViewVisibility(R.id.w_opts, View.GONE);
            v.setViewVisibility(R.id.w_answer, View.VISIBLE);
        }

        Intent skip = new Intent(c, TokenWidget.class).setAction(ACTION_SKIP);
        PendingIntent skipPi = PendingIntent.getBroadcast(c, 2, skip,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        v.setOnClickPendingIntent(R.id.w_skip, skipPi);
        return v;
    }
}
