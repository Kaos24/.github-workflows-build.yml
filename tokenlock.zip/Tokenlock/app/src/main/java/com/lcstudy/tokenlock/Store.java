package com.lcstudy.tokenlock;

import android.content.Context;
import android.content.SharedPreferences;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

/** All saved state: tokens, XP, streaks, settings and the question order. */
final class Store {
    static final int DAILY_GOAL = 10;
    static final int COMBO_BONUS_EVERY = 5;
    static final int LUCKY_PERCENT = 6;

    /** A question you got wrong or revealed comes back after this many other questions. */
    static final int REVIEW_GAP = 15;
    /** A skipped question comes back after this many. */
    static final int SKIP_GAP = 100;
    /** A question never reappears within this many questions of its last showing (smaller if few are enabled). */
    static final int MIN_GAP = 40;
    private static final int RECENT_MAX = 60;

    static final int MODE_MIXED = 0, MODE_TYPED = 1, MODE_CHOICE = 2;

    private final SharedPreferences p;
    private static final Random RND = new Random();

    private Store(Context c) {
        p = c.getApplicationContext().getSharedPreferences("tokenlock", Context.MODE_PRIVATE);
    }

    /** For tests. */
    Store(SharedPreferences prefs) { p = prefs; }

    static Store get(Context c) { return new Store(c); }

    static long today() { return LocalDate.now().toEpochDay(); }

    // ---------------- tokens ----------------
    int tokens() { return p.getInt("tokens", 0); }

    synchronized boolean spend(int n) {
        int t = tokens();
        if (t < n) return false;
        p.edit().putInt("tokens", t - n).putInt("spent", p.getInt("spent", 0) + n).apply();
        return true;
    }

    // ---------------- settings ----------------
    /** -1 means "use the default for this app". */
    int costOverride(String pkg) { return p.getInt("cost_" + pkg, -1); }

    void setCostOverride(String pkg, int cost) {
        if (cost < 0) p.edit().remove("cost_" + pkg).apply();
        else p.edit().putInt("cost_" + pkg, cost).apply();
    }

    int graceMinutes() { return p.getInt("graceMin", 1); }
    void setGraceMinutes(int m) { p.edit().putInt("graceMin", m).apply(); }
    long graceMs() { return graceMinutes() * 60_000L; }

    boolean subjectOn(char s) { return p.getBoolean("subj_" + s, true); }

    void setSubjectOn(char s, boolean on) { p.edit().putBoolean("subj_" + s, on).apply(); }

    int mode() { return p.getInt("mode", MODE_MIXED); }
    void setMode(int m) { p.edit().putInt("mode", m).apply(); }

    /** Whether a question is in rotation under the current subject/type settings. */
    boolean enabled(Question q) {
        boolean anySubject = subjectOn('C') || subjectOn('P') || subjectOn('H');
        if (anySubject && !subjectOn(q.subject)) return false;
        int m = mode();
        if (m == MODE_TYPED && q.isChoice()) return false;
        if (m == MODE_CHOICE && !q.isChoice()) return false;
        return true;
    }

    // ---------------- progress ----------------
    int xp() { return p.getInt("xp", 0); }
    int level() { return levelFor(xp()); }

    static int levelFor(int xp) {
        int n = 1;
        while (levelStart(n + 1) <= xp) n++;
        return n;
    }

    /** XP needed to reach a level: 0, 100, 300, 600, 1000... */
    static int levelStart(int level) { return 100 * (level - 1) * level / 2; }

    int streak() {
        long last = p.getLong("lastDay", -10);
        return last >= today() - 1 ? p.getInt("streak", 0) : 0;
    }

    int todayCorrect() {
        return p.getLong("todayDay", -1) == today() ? p.getInt("todayCorrect", 0) : 0;
    }

    int combo() { return p.getInt("combo", 0); }
    int answered() { return p.getInt("answered", 0); }
    int correctCount() { return p.getInt("correct", 0); }
    int spent() { return p.getInt("spent", 0); }
    int bestCombo() { return p.getInt("bestCombo", 0); }

    int accuracy() {
        int a = answered();
        return a == 0 ? 0 : Math.round(100f * correctCount() / a);
    }

    int subjectAnswered(char s) { return p.getInt("ans_" + s, 0); }
    int subjectCorrect(char s) { return p.getInt("cor_" + s, 0); }

    static final class Reward {
        int tokens;
        int xp;
        final ArrayList<String> notes = new ArrayList<>();
    }

    /** Records a correct answer and returns what was earned. Does not move to the next question. */
    synchronized Reward correct(Question q, boolean alreadyCounted) {
        Reward r = new Reward();
        long day = today();
        SharedPreferences.Editor e = p.edit();

        int combo = combo() + 1;
        r.tokens = 1;
        r.xp = 10 + (q.difficulty - 1) * 5 + Math.min(combo - 1, 10);

        if (RND.nextInt(100) < LUCKY_PERCENT) {
            r.tokens += 1;
            r.notes.add("Lucky question: double token");
        }
        if (combo % COMBO_BONUS_EVERY == 0) {
            r.tokens += 1;
            r.notes.add(combo + " in a row: bonus token");
        }

        int todayCount = todayCorrect() + 1;
        if (todayCount == DAILY_GOAL) {
            r.tokens += 2;
            r.notes.add("Daily goal done: +2 tokens");
        }

        long last = p.getLong("lastDay", -10);
        int streak = p.getInt("streak", 0);
        if (last != day) {
            streak = (last == day - 1) ? streak + 1 : 1;
            if (streak > 1) r.notes.add(streak + "-day streak");
            e.putInt("streak", streak).putLong("lastDay", day);
        }

        int oldXp = xp();
        int newXp = oldXp + r.xp;
        if (levelFor(newXp) > levelFor(oldXp)) r.notes.add("Level " + levelFor(newXp) + " reached");

        e.putInt("tokens", tokens() + r.tokens)
                .putInt("xp", newXp)
                .putInt("combo", combo)
                .putInt("bestCombo", Math.max(bestCombo(), combo))
                .putLong("todayDay", day)
                .putInt("todayCorrect", todayCount)
                .putInt("correct", correctCount() + 1)
                .putInt("cor_" + q.subject, subjectCorrect(q.subject) + 1)
                .putInt("earned", p.getInt("earned", 0) + r.tokens);
        e.remove("miss_" + q.id);
        if (!alreadyCounted) {
            e.putInt("answered", answered() + 1).putInt("ans_" + q.subject, subjectAnswered(q.subject) + 1);
        }
        e.apply();
        return r;
    }

    void wrongAttempt() { p.edit().putInt("combo", 0).apply(); }

    /** Revealed or answered wrong: no token, and it comes back for review later. Does not advance. */
    synchronized void missed(QuestionBank bank, Question q) {
        int misses = p.getInt("miss_" + q.id, 0);
        p.edit().putInt("combo", 0)
                .putInt("answered", answered() + 1)
                .putInt("ans_" + q.subject, subjectAnswered(q.subject) + 1)
                .putInt("miss_" + q.id, misses + 1)
                .apply();
        // Each repeat miss pushes it further away: 15, 30, 60, then 120 questions.
        schedule(q.id, REVIEW_GAP << Math.min(misses, 3));
    }

    // ---------------- question order ----------------
    // A shuffled "bag" of every question gives each round a fresh order with no repeats.
    // Missed and skipped questions go into a separate review queue with a due time.
    // A list of recently shown questions stops anything reappearing too soon.

    synchronized int currentId(QuestionBank bank) {
        int id = p.getInt("cur", -1);
        if (id < 0 || id >= bank.size() || p.getInt("bagSig", -1) != bank.size() || !enabled(bank.get(id))) {
            id = advance(bank);
        }
        return id;
    }

    /** Seed for the option order of the current question, so widget and popup match. */
    long seed() { return p.getLong("seed", 0); }

    /** Number of questions shown so far. Changes every time we advance. */
    int seq() { return p.getInt("seq", 0); }

    synchronized int advance(QuestionBank bank) {
        int n = bank.size();
        ArrayList<Integer> bag = loadBag(bank);
        int pos = p.getInt("bagPos", 0);
        ArrayList<Integer> recent = ints(p.getString("recent", ""), n);
        LinkedHashMap<Integer, Integer> review = reviewMap(n);
        int seq = seq() + 1;
        int cur = p.getInt("cur", -1);

        int eligible = 0;
        for (int i = 0; i < n; i++) if (enabled(bank.get(i))) eligible++;
        int gap = Math.max(0, Math.min(MIN_GAP, (eligible - 1) / 2));
        int round = p.getInt("round", 0);

        int pick = -1;

        // 1. A review question that is due.
        Iterator<Map.Entry<Integer, Integer>> it = review.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<Integer, Integer> en = it.next();
            int id = en.getKey();
            if (!enabled(bank.get(id))) continue;
            if (en.getValue() <= seq && id != cur && !shownWithin(recent, id, Math.min(gap, 10))) {
                pick = id;
                it.remove();
                break;
            }
        }

        // 2. The next fresh question from the bag.
        if (pick < 0) {
            for (int pass = 0; pass < 2 && pick < 0; pass++) {
                for (int j = pos; j < bag.size(); j++) {
                    int id = bag.get(j);
                    if (!enabled(bank.get(id)) || id == cur || review.containsKey(id) || shownWithin(recent, id, gap)) continue;
                    Collections.swap(bag, j, pos);
                    pick = id;
                    pos++;
                    break;
                }
                if (pick < 0 && pass == 0) {
                    // Round finished: reshuffle everything.
                    bag = shuffled(n);
                    pos = 0;
                    round++;
                }
            }
        }

        // 3. Fallback for tiny selections: anything enabled that isn't the current one.
        if (pick < 0) {
            ArrayList<Integer> any = new ArrayList<>();
            for (int i = 0; i < n; i++) if (enabled(bank.get(i)) && i != cur) any.add(i);
            if (any.isEmpty()) for (int i = 0; i < n; i++) if (enabled(bank.get(i))) any.add(i);
            pick = any.isEmpty() ? 0 : any.get(RND.nextInt(any.size()));
            review.remove(pick);
        }

        recent.add(pick);
        while (recent.size() > RECENT_MAX) recent.remove(0);

        p.edit()
                .putString("bag", join(bag))
                .putInt("bagPos", pos)
                .putInt("bagSig", n)
                .putString("recent", join(recent))
                .putString("review", joinReview(review))
                .putInt("seq", seq)
                .putInt("round", round)
                .putInt("cur", pick)
                .putLong("seed", RND.nextLong())
                .apply();
        return pick;
    }

    synchronized void skip(QuestionBank bank) {
        int id = currentId(bank);
        schedule(id, SKIP_GAP);
        advance(bank);
    }

    int seenThisRound() { return p.getInt("bagPos", 0); }
    int round() { return p.getInt("round", 0) + 1; }
    int reviewCount() { return reviewMap(Integer.MAX_VALUE).size(); }

    /** Short message shown on the widget after answering there. Only valid until the next question change. */
    void setFlash(String text, boolean good) {
        p.edit().putString("flash", text).putBoolean("flashGood", good).putInt("flashSeq", seq()).apply();
    }

    String flash() {
        return p.getInt("flashSeq", -1) == seq() ? p.getString("flash", null) : null;
    }

    boolean flashGood() { return p.getBoolean("flashGood", true); }

    private void schedule(int id, int gap) {
        LinkedHashMap<Integer, Integer> review = reviewMap(Integer.MAX_VALUE);
        review.remove(id);
        review.put(id, seq() + gap);
        p.edit().putString("review", joinReview(review)).apply();
    }

    private static boolean shownWithin(List<Integer> recent, int id, int gap) {
        for (int i = recent.size() - 1, k = 0; i >= 0 && k < gap; i--, k++) {
            if (recent.get(i) == id) return true;
        }
        return false;
    }

    private ArrayList<Integer> loadBag(QuestionBank bank) {
        int n = bank.size();
        int sig = p.getInt("bagSig", -1);
        ArrayList<Integer> bag = ints(p.getString("bag", ""), n);
        int pos = Math.min(p.getInt("bagPos", 0), bag.size());
        if (sig == n && !bag.isEmpty()) return dedupe(bag);

        if (bag.isEmpty() || sig < 0) {
            bag = shuffled(n);
            p.edit().putInt("bagPos", 0).apply();
            return bag;
        }
        // The question bank changed size (e.g. an update added questions):
        // keep progress and slot the new questions randomly into the unplayed part.
        bag = dedupe(bag);
        for (int id = Math.max(0, sig); id < n; id++) {
            int at = pos + RND.nextInt(bag.size() - pos + 1);
            bag.add(at, id);
        }
        for (int id = 0; id < n; id++) {
            if (!bag.contains(id)) bag.add(pos + RND.nextInt(bag.size() - pos + 1), id);
        }
        p.edit().putInt("bagPos", Math.min(pos, bag.size())).apply();
        return bag;
    }

    private static ArrayList<Integer> dedupe(ArrayList<Integer> bag) {
        ArrayList<Integer> out = new ArrayList<>(bag.size());
        java.util.HashSet<Integer> seen = new java.util.HashSet<>();
        for (int v : bag) if (seen.add(v)) out.add(v);
        return out;
    }

    private LinkedHashMap<Integer, Integer> reviewMap(int n) {
        LinkedHashMap<Integer, Integer> m = new LinkedHashMap<>();
        String s = p.getString("review", "");
        if (s.isEmpty()) return m;
        for (String part : s.split(",")) {
            int c = part.indexOf(':');
            if (c <= 0) continue;
            try {
                int id = Integer.parseInt(part.substring(0, c));
                int due = Integer.parseInt(part.substring(c + 1));
                if (id >= 0 && id < n) m.put(id, due);
            } catch (NumberFormatException ignored) {
            }
        }
        return m;
    }

    private static String joinReview(LinkedHashMap<Integer, Integer> m) {
        StringBuilder b = new StringBuilder();
        for (Map.Entry<Integer, Integer> e : m.entrySet()) {
            if (b.length() > 0) b.append(',');
            b.append(e.getKey()).append(':').append(e.getValue());
        }
        return b.toString();
    }

    private static ArrayList<Integer> ints(String s, int n) {
        ArrayList<Integer> out = new ArrayList<>();
        if (s == null || s.isEmpty()) return out;
        for (String part : s.split(",")) {
            try {
                int v = Integer.parseInt(part);
                if (v >= 0 && v < n) out.add(v);
            } catch (NumberFormatException ignored) {
            }
        }
        return out;
    }

    private static String join(List<Integer> list) {
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < list.size(); i++) {
            if (i > 0) b.append(',');
            b.append(list.get(i));
        }
        return b.toString();
    }

    private static ArrayList<Integer> shuffled(int n) {
        ArrayList<Integer> list = new ArrayList<>(n);
        for (int i = 0; i < n; i++) list.add(i);
        Collections.shuffle(list, RND);
        return list;
    }
}
