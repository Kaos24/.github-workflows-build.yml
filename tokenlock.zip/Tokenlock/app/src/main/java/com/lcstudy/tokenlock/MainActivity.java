package com.lcstudy.tokenlock;

import android.app.Activity;
import android.appwidget.AppWidgetManager;
import android.content.ComponentName;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.GridLayout;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

/** Setup, settings and stats. */
public class MainActivity extends Activity {

    private static final char[] SUBJECTS = {'C', 'P', 'H'};
    private static final int[] GRACE_CHOICES = {1, 2, 5, 10};

    private TextView coin, statusTitle, statusBody, turnOn, appInfo;
    private LinearLayout subjectRow, modeRow, graceRow, subjectStats;
    private GridLayout stats;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(build());
    }

    @Override
    protected void onResume() {
        super.onResume();
        refresh();
        TokenWidget.refresh(this);
    }

    private View build() {
        int pad = Ui.dp(this, 22);
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(pad, Ui.dp(this, 40), pad, Ui.dp(this, 40));

        LinearLayout head = new LinearLayout(this);
        head.setGravity(Gravity.CENTER_VERTICAL);
        head.addView(Ui.text(this, "Tokenlock", 30, Ui.TEXT, true), new LinearLayout.LayoutParams(0, -2, 1f));
        coin = Ui.text(this, "0", 20, Ui.ON_COIN, true);
        coin.setGravity(Gravity.CENTER);
        coin.setBackground(Ui.coin(this));
        int cs = Ui.dp(this, 54);
        head.addView(coin, new LinearLayout.LayoutParams(cs, cs));
        col.addView(head);

        TextView sub = Ui.text(this, "Earn tokens by answering Leaving Cert questions. Spend them to open apps.", 15, Ui.MUTED, false);
        sub.setLineSpacing(0, 1.2f);
        col.addView(sub, top(6));

        // Blocking status
        LinearLayout status = card();
        statusTitle = Ui.text(this, "", 17, Ui.TEXT, true);
        status.addView(statusTitle);
        statusBody = Ui.text(this, "", 14, Ui.MUTED, false);
        statusBody.setLineSpacing(0, 1.25f);
        status.addView(statusBody, top(6));
        turnOn = Ui.button(this, "Turn on app blocking", true);
        turnOn.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
        status.addView(turnOn, top(14));
        appInfo = Ui.button(this, "Open App info (for restricted setting)", false);
        appInfo.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                Uri.parse("package:" + getPackageName()))));
        status.addView(appInfo, top(10));
        col.addView(status, top(22));

        TextView practice = Ui.button(this, "Answer questions now", true);
        practice.setOnClickListener(v -> startActivity(new Intent(this, QuizActivity.class)));
        col.addView(practice, top(14));
        TextView apps = Ui.button(this, "Choose what each app costs", false);
        apps.setOnClickListener(v -> startActivity(new Intent(this, AppsActivity.class)));
        col.addView(apps, top(10));
        TextView widget = Ui.button(this, "Add widget to home screen", false);
        widget.setOnClickListener(v -> pinWidget());
        col.addView(widget, top(10));

        // Question settings
        col.addView(Ui.text(this, "Subjects", 17, Ui.TEXT, true), top(28));
        subjectRow = row();
        col.addView(scroll(subjectRow), top(8));

        col.addView(Ui.text(this, "Question type", 17, Ui.TEXT, true), top(20));
        modeRow = row();
        col.addView(scroll(modeRow), top(8));

        col.addView(Ui.text(this, "Keep an app open after leaving it for", 17, Ui.TEXT, true), top(20));
        graceRow = row();
        col.addView(scroll(graceRow), top(8));

        // Stats
        col.addView(Ui.text(this, "Your progress", 17, Ui.TEXT, true), top(28));
        stats = new GridLayout(this);
        stats.setColumnCount(2);
        col.addView(stats, top(8));
        subjectStats = new LinearLayout(this);
        subjectStats.setOrientation(LinearLayout.VERTICAL);
        col.addView(subjectStats, top(8));

        // Rules
        col.addView(Ui.text(this, "How it works", 17, Ui.TEXT, true), top(26));
        TextView rules = Ui.text(this,
                "Each correct answer earns 1 token. Five in a row earns a bonus token, and some questions are lucky and pay double. "
                        + "Hit " + Store.DAILY_GOAL + " correct in a day for 2 extra tokens.\n\n"
                        + "Multiple-choice questions can be answered right on the widget. You get one try.\n\n"
                        + "By default most apps cost " + Config.NORMAL_COST + " token, YouTube, Instagram and TikTok cost "
                        + Config.HIGH_COST + ", and WhatsApp is free. Change any of them under Choose what each app costs.\n\n"
                        + "Phone, Contacts, Settings, Clock and emergency apps are always free.\n\n"
                        + "Got one wrong or tapped Show answer? No token, but it comes back later so you can learn it.",
                14, Ui.MUTED, false);
        rules.setLineSpacing(0, 1.3f);
        col.addView(rules, top(8));

        ScrollView sv = new ScrollView(this);
        sv.setBackgroundColor(Ui.BG);
        sv.addView(col);
        return sv;
    }

    private void refresh() {
        Store st = Store.get(this);
        QuestionBank bank = QuestionBank.get(this);
        coin.setText(String.valueOf(st.tokens()));

        boolean on = isGuardEnabled();
        statusTitle.setText(on ? "App blocking is on" : "App blocking is off");
        statusTitle.setTextColor(on ? Ui.GOOD : Ui.BAD);
        statusBody.setText(on
                ? "Apps will ask for tokens when you open them."
                : "Tap the button below, find Tokenlock under Installed apps or Downloaded apps, and switch it on.\n\n"
                + "If Android says it's a restricted setting: tap Open App info, tap the ⋮ menu in the top corner, "
                + "choose Allow restricted settings, then try again.");
        turnOn.setVisibility(on ? View.GONE : View.VISIBLE);
        appInfo.setVisibility(on ? View.GONE : View.VISIBLE);

        // Subjects
        subjectRow.removeAllViews();
        for (char s : SUBJECTS) {
            boolean enabled = st.subjectOn(s);
            TextView chip = Ui.chip(this, Question.subjectName(s) + "  " + bank.count(s), enabled, Question.color(s));
            chip.setOnClickListener(v -> {
                int onCount = 0;
                for (char x : SUBJECTS) if (st.subjectOn(x)) onCount++;
                if (enabled && onCount == 1) {
                    Toast.makeText(this, "Keep at least one subject on.", Toast.LENGTH_SHORT).show();
                    return;
                }
                st.setSubjectOn(s, !enabled);
                settingsChanged();
            });
            subjectRow.addView(chip, chipLp());
        }

        // Question type
        modeRow.removeAllViews();
        String[] modes = {"Mixed", "Typed only", "Multiple choice only"};
        for (int m = 0; m < modes.length; m++) {
            final int mode = m;
            TextView chip = Ui.chip(this, modes[m], st.mode() == m, Ui.COIN);
            chip.setOnClickListener(v -> {
                st.setMode(mode);
                settingsChanged();
            });
            modeRow.addView(chip, chipLp());
        }

        // Grace period
        graceRow.removeAllViews();
        for (int g : GRACE_CHOICES) {
            TextView chip = Ui.chip(this, g + (g == 1 ? " minute" : " minutes"), st.graceMinutes() == g, Ui.COIN);
            chip.setOnClickListener(v -> {
                st.setGraceMinutes(g);
                refresh();
            });
            graceRow.addView(chip, chipLp());
        }

        // Stats
        stats.removeAllViews();
        int lvl = st.level();
        addStat("Tokens", String.valueOf(st.tokens()));
        addStat("Level", lvl + "  (" + (st.xp() - Store.levelStart(lvl)) + "/" + (Store.levelStart(lvl + 1) - Store.levelStart(lvl)) + " XP)");
        addStat("Day streak", String.valueOf(st.streak()));
        addStat("Today", st.todayCorrect() + " of " + Store.DAILY_GOAL);
        addStat("Accuracy", st.answered() == 0 ? "–" : st.accuracy() + "%");
        addStat("Best run", String.valueOf(st.bestCombo()));
        addStat("Correct answers", String.valueOf(st.correctCount()));
        addStat("Tokens spent", String.valueOf(st.spent()));
        addStat("Question bank", bank.size() + " questions");
        addStat("To review", String.valueOf(st.reviewCount()));

        subjectStats.removeAllViews();
        for (char s : SUBJECTS) {
            int a = st.subjectAnswered(s), c = st.subjectCorrect(s);
            String line = Question.subjectName(s) + ":  " + (a == 0 ? "no answers yet" : Math.round(100f * c / a) + "% of " + a);
            TextView t = Ui.text(this, line, 14, Question.color(s), false);
            t.setPadding(0, Ui.dp(this, 3), 0, Ui.dp(this, 3));
            subjectStats.addView(t);
        }
    }

    private void settingsChanged() {
        Store st = Store.get(this);
        QuestionBank bank = QuestionBank.get(this);
        // If the current question no longer fits the settings, move on.
        if (!st.enabled(bank.get(st.currentId(bank)))) st.advance(bank);
        TokenWidget.refresh(this);
        refresh();
    }

    private void addStat(String label, String value) {
        LinearLayout cell = new LinearLayout(this);
        cell.setOrientation(LinearLayout.VERTICAL);
        cell.setPadding(0, Ui.dp(this, 8), Ui.dp(this, 12), Ui.dp(this, 8));
        cell.addView(Ui.text(this, value, 18, Ui.TEXT, true));
        cell.addView(Ui.text(this, label, 12, Ui.MUTED, false));
        GridLayout.LayoutParams lp = new GridLayout.LayoutParams(
                GridLayout.spec(GridLayout.UNDEFINED), GridLayout.spec(GridLayout.UNDEFINED, 1f));
        lp.width = 0;
        stats.addView(cell, lp);
    }

    private boolean isGuardEnabled() {
        String s = Settings.Secure.getString(getContentResolver(), Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
        if (s == null) return false;
        ComponentName cn = new ComponentName(this, GuardService.class);
        return s.contains(cn.flattenToString()) || s.contains(cn.flattenToShortString());
    }

    private void pinWidget() {
        AppWidgetManager m = AppWidgetManager.getInstance(this);
        if (m.isRequestPinAppWidgetSupported()) {
            m.requestPinAppWidget(new ComponentName(this, TokenWidget.class), null, null);
        } else {
            Toast.makeText(this, "Long-press your home screen, tap Widgets, and find Tokenlock.", Toast.LENGTH_LONG).show();
        }
    }

    private LinearLayout row() {
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.HORIZONTAL);
        return r;
    }

    private HorizontalScrollView scroll(View v) {
        HorizontalScrollView h = new HorizontalScrollView(this);
        h.setHorizontalScrollBarEnabled(false);
        h.addView(v);
        return h;
    }

    private LinearLayout.LayoutParams chipLp() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
        lp.rightMargin = Ui.dp(this, 8);
        return lp;
    }

    private LinearLayout card() {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        int p = Ui.dp(this, 18);
        c.setPadding(p, p, p, p);
        c.setBackground(Ui.round(this, Ui.CARD, 20));
        return c;
    }

    private LinearLayout.LayoutParams top(int dp) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.topMargin = Ui.dp(this, dp);
        return lp;
    }
}
