package com.lcstudy.tokenlock;

import java.util.Random;

/**
 * One study question. Typed questions use Checker keys.
 * Multiple-choice questions have keys starting with '@': @correct^wrong^wrong^wrong
 */
final class Question {
    final int id;
    final char subject; // C = Computer Science, P = Physics, H = Chemistry
    final int difficulty; // 1..3
    final String text;
    final String answer;
    final String keys;
    /** For multiple choice: options[0] is the correct one. Null for typed questions. */
    final String[] options;

    Question(int id, char subject, int difficulty, String text, String answer, String keys) {
        this.id = id;
        this.subject = subject;
        this.difficulty = Math.max(1, Math.min(3, difficulty));
        this.text = text;
        this.answer = answer;
        if (keys.startsWith("@")) {
            String[] o = keys.substring(1).split("\\^");
            for (int i = 0; i < o.length; i++) o[i] = o[i].trim();
            this.options = o.length >= 2 ? o : null;
        } else {
            this.options = null;
        }
        this.keys = keys;
    }

    boolean isChoice() { return options != null; }

    /** Display order of the options for a given seed. order[displayIndex] = index into options. */
    int[] order(long seed) {
        int n = options.length;
        int[] o = new int[n];
        for (int i = 0; i < n; i++) o[i] = i;
        Random r = new Random(seed * 31 + id);
        for (int i = n - 1; i > 0; i--) {
            int j = r.nextInt(i + 1);
            int t = o[i]; o[i] = o[j]; o[j] = t;
        }
        return o;
    }

    String subjectName() {
        switch (subject) {
            case 'C': return "Computer Science";
            case 'P': return "Physics";
            default: return "Chemistry";
        }
    }

    static String subjectName(char s) {
        switch (s) {
            case 'C': return "Computer Science";
            case 'P': return "Physics";
            default: return "Chemistry";
        }
    }

    int color() { return color(subject); }

    static int color(char s) {
        switch (s) {
            case 'C': return Ui.CS;
            case 'P': return Ui.PHYSICS;
            default: return Ui.CHEM;
        }
    }

    String dots() {
        StringBuilder b = new StringBuilder();
        for (int i = 1; i <= 3; i++) b.append(i <= difficulty ? '●' : '○');
        return b.toString();
    }
}
