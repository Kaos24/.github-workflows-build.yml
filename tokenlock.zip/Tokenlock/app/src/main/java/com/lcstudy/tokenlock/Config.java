package com.lcstudy.tokenlock;

import android.content.Context;
import android.telecom.TelecomManager;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

/** Which apps cost what. Users change costs in the app; these are the defaults. */
final class Config {
    private Config() {}

    static final int NORMAL_COST = 1;
    static final int HIGH_COST = 3;

    /** Choices offered in the app-cost picker. 0 = free. */
    static final int[] COST_CHOICES = {0, 1, 2, 3, 5};

    /** 3 tokens by default. */
    static final Set<String> HIGH = new HashSet<>(Arrays.asList(
            "com.google.android.youtube",
            "com.instagram.android",
            "com.instagram.lite",
            "com.zhiliaoapp.musically",      // TikTok
            "com.ss.android.ugc.trill",      // TikTok (some regions)
            "com.zhiliaoapp.musically.go"    // TikTok Lite
    ));

    /** Free by default, but you can change them. */
    static final Set<String> DEFAULT_FREE = new HashSet<>(Arrays.asList(
            "com.whatsapp", "com.whatsapp.w4b"
    ));

    /** Always free and can't be changed, so you can never be locked out of calls, alarms or settings. */
    static final Set<String> ALWAYS_FREE = new HashSet<>(Arrays.asList(
            "com.google.android.dialer", "com.android.dialer", "com.samsung.android.dialer",
            "com.android.phone", "com.android.server.telecom", "com.samsung.android.incallui",
            "com.google.android.contacts", "com.android.contacts", "com.samsung.android.app.contacts",
            "com.android.settings",
            "com.google.android.deskclock", "com.android.deskclock", "com.sec.android.app.clockpackage",
            "com.android.emergency", "com.google.android.apps.safetyhub", "com.sec.android.app.safetyassurance"
    ));

    /** System surfaces that are never apps you "open". */
    static final Set<String> SYSTEM = new HashSet<>(Arrays.asList(
            "android", "com.android.systemui",
            "com.android.permissioncontroller", "com.google.android.permissioncontroller",
            "com.android.packageinstaller", "com.google.android.packageinstaller",
            "com.android.intentresolver"
    ));

    static boolean alwaysFree(Context c, String pkg) {
        if (ALWAYS_FREE.contains(pkg)) return true;
        try {
            TelecomManager tm = c.getSystemService(TelecomManager.class);
            if (tm != null && pkg.equals(tm.getDefaultDialerPackage())) return true;
        } catch (Exception ignored) {
        }
        return false;
    }

    static int defaultCost(String pkg) {
        if (DEFAULT_FREE.contains(pkg)) return 0;
        if (HIGH.contains(pkg)) return HIGH_COST;
        return NORMAL_COST;
    }

    static int cost(Context c, String pkg) {
        if (alwaysFree(c, pkg)) return 0;
        int o = Store.get(c).costOverride(pkg);
        return o >= 0 ? o : defaultCost(pkg);
    }

    static String label(int cost) {
        if (cost <= 0) return "Free";
        return cost + (cost == 1 ? " token" : " tokens");
    }
}
