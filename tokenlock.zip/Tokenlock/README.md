# Tokenlock v2

A Leaving Cert study app for Android. Answer questions to earn tokens, spend tokens to open apps.

## Change the rules
- App costs: in the app, tap "Choose what each app costs". Defaults live in `Config.java`.
- Subjects, question type and the grace period: on the app's main screen.
- Daily goal, bonus odds, review gaps: `Store.java`.
- Questions: `app/src/main/assets/questions.txt`. Always add new questions at the END of the file so saved progress stays in step.

## Signing
`app/tokenlock.keystore` is a fixed key so each new build installs over the last one and keeps your tokens.
